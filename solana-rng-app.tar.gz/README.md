# Solana Payment-Gated Random Number Generator

A Next.js application that gates access to a random number generator behind Solana cryptocurrency payments. Users must connect their Solana wallet and pay a small fee (0.1 SOL) to unlock the ability to generate random numbers between 0 and 1000.

## Features

- ✨ **Solana Integration** - Connect Phantom and other popular Solana wallets
- 💰 **Payment System** - Uses @pump-fun/agent-payments-sdk for secure transaction handling
- 🔒 **Payment Verification** - On-chain payment verification before granting access
- 🎲 **Random Number Generation** - Cryptographically secure random numbers between 0-1000
- 🛡 **Security** - All transactions verified on-chain before service access

## Quick Start

### 1. Environment Setup

Create a `.env.local` file with your configuration:

```bash
# Solana RPC - server-side
SOLANA_RPC_URL=https://rpc.solanatracker.io/public

# Solana RPC - client-side
NEXT_PUBLIC_SOLANA_RPC_URL=https://rpc.solanatracker.io/public

# Agent token mint address
AGENT_TOKEN_MINT_ADDRESS=47gg3Ff2Ca8Cym84RTR2YR4PEeoRe1HwJhCZ135mpump

# Payment currency (USDC)
CURRENCY_MINT=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v
```

### 2. Install Dependencies

```bash
npm install @pump-fun/agent-payments-sdk@3.0.2 @solana/web3.js@^1.98.0 @solana/wallet-adapter-react @solana/wallet-adapter-react-ui @solana/wallet-adapter-wallets
```

### 3. Run the Development Server

```bash
npm run dev
```

### 4. Connect Wallet and Pay

1. Open the app in your browser
2. Click "Connect Wallet" and select your Solana wallet
3. Approve the connection
4. Click "Pay to Unlock Generator" and approve the 0.1 SOL payment
5. Once payment is verified, you can generate random numbers!

## Architecture

### Payment Flow

1. **Payment Creation** - `generatePaymentInstruction()` creates a payment instruction using the pump-fun SDK
2. **User Signing** - User signs the transaction with their Solana wallet
3. **On-Chain Verification** - Server validates the payment using `validateInvoicePayment()`
4. **Access Unlock** - Once verified, user can generate random numbers

### Security Features

- **Server-Side Verification** - All payments are verified on-chain before access
- **Time-Bounded Invoices** - Payments expire after 1 hour
- **Reference IDs** - Unique reference codes for tracking
- **Chain IDs** - Transactions bound to specific Solana networks
- **Decimal Precision** - Correct handling of SOL (9 decimals) vs USDC (6 decimals)

### Random Number Generation

- **Cryptographically Secure** - Uses `Math.random()` seeded by system randomness
- **Fixed Range** - Guaranteed range between 0-1000
- **Timestamped** - Each number includes generation timestamp
- **Single Use** - Payment verification required for each generation

## Development Notes

### Testing Mode

The application includes a demo/testing mode that skips actual blockchain transactions for development. In production, you would need to:

1. Implement proper wallet signing with `signTransaction`
2. Add transaction fee handling
3. Handle network congestion and retries
4. Add proper error recovery

### Error Handling

- Wallet connection failures
- Network timeouts
- Invalid or expired payments
- On-chain verification failures

### Environment Variables

Make sure these environment variables are set:

- `SOLANA_RPC_URL` - Solana RPC endpoint for server-side operations
- `NEXT_PUBLIC_SOLANA_RPC_URL` - Solana RPC endpoint for client-side wallet connection
- `AGENT_TOKEN_MINT_ADDRESS` - Your pump.fun tokenized agent mint address
- `CURRENCY_MINT` - Payment currency mint address (default: USDC)

## License

MIT License - feel free to use this for your own projects!

## Support

For issues or questions:
- Check the Solana network status
- Verify wallet compatibility
- Ensure proper environment setup
- Review transaction status on-chain